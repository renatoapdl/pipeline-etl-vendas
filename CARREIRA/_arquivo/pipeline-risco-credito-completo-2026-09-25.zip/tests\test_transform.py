"""Testes das regras de transformacao e do calculo de risco.

Os testes usam Spark local em modo fixture simples para rodar rapido em CI.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

pyspark = pytest.importorskip("pyspark", reason="pyspark nao instalado")

from pyspark.sql import SparkSession  # noqa: E402

from risk.provisoes import Exposicao, calcular, LGD_PADRAO  # noqa: E402


@pytest.fixture(scope="session")
def spark():
    s = (
        SparkSession.builder
        .master("local[1]")
        .appName("testes-pipeline")
        .config("spark.sql.shuffle.partitions", "2")
        .config("spark.driver.host", "127.0.0.1")
        .config("spark.driver.bindAddress", "127.0.0.1")
        .getOrCreate()
    )
    yield s
    s.stop()


def _linhas(df):
    return {r["id_cliente"]: r for r in df.collect()}


def test_nulos_tratados_com_valor_padrao(spark):
    from pipeline import transform

    df = spark.createDataFrame(
        [("CLI1", 0.0, "2025-01-10"), ("CLI2", 5000.0, "2025-01-10")],
        "id_cliente string, limite_atribuido double, data_avaliacao string",
    )
    out = transform.normalizar_limites(df)
    linhas = _linhas(out)

    assert linhas["CLI1"]["limite_atribuido"] == 0
    assert linhas["CLI1"]["flag_limite_nulo"] == 1
    assert linhas["CLI2"]["flag_limite_nulo"] == 0


def test_deduplicacao_mantem_avaliacao_mais_recente(spark):
    from pipeline import transform

    df = spark.createDataFrame(
        [("CLI1", 100.0, "2025-01-10"), ("CLI1", 900.0, "2025-06-10")],
        "id_cliente string, limite_atribuido double, data_avaliacao string",
    )
    linhas = _linhas(transform.normalizar_limites(df))
    assert linhas["CLI1"]["limite_atribuido"] == 900.0


def test_campo_derivado_uso_limite(spark):
    from pipeline import transform

    clientes = spark.createDataFrame(
        [("CLI1", "varejo", 100_000.0)], "id_cliente string, segmento string, faturamento_anual double"
    )
    limites = spark.createDataFrame(
        [("CLI1", 50_000.0, 0, "2025-01-01")],
        "id_cliente string, limite_atribuido double, flag_limite_nulo int, data_avaliacao string",
    )
    propostas = spark.createDataFrame(
        [("PROP1", "CLI1", "aprovada")],
        "id_proposta string, id_cliente string, situacao_padrao string",
    )
    out = transform.criar_campos_derivados(clientes, propostas, limites).collect()[0]

    assert out["uso_limite"] == 0.5
    assert out["cliente_ativo"] == 1
    assert out["qtd_propostas_aprovadas"] == 1


def test_divisao_por_zero_nao_quebra(spark):
    from pipeline import transform

    clientes = spark.createDataFrame(
        [("CLI1", "varejo", 0.0)], "id_cliente string, segmento string, faturamento_anual double"
    )
    limites = spark.createDataFrame(
        [("CLI1", 50_000.0, 1, "2025-01-01")],
        "id_cliente string, limite_atribuido double, flag_limite_nulo int, data_avaliacao string",
    )
    propostas = spark.createDataFrame(
        [], "id_proposta string, id_cliente string, situacao_padrao string"
    )
    out = transform.criar_campos_derivados(clientes, propostas, limites).collect()[0]
    assert out["uso_limite"] == 0.0


def test_situacao_controlada(spark):
    from pipeline import transform

    df = spark.createDataFrame(
        [("PROP1", "  APROVADA ", "APROVADA"), ("PROP2", "recusada", "recusada"),
         ("PROP3", "vazio", "")],
        "id_proposta string, situacao string, situacao_padrao string",
    )
    out = {r["id_proposta"]: r["situacao_padrao"] for r in transform.normalizar_propostas(df).collect()}
    assert out["PROP1"] == "aprovada"
    assert out["PROP2"] == "recusada"
    assert out["PROP3"] == "desconhecida"


def test_quality_gate_reprova_duplicidade(spark):
    from pipeline import quality

    df = spark.createDataFrame(
        [("CLI1",), ("CLI1",)], "id_cliente string"
    )
    resultado = quality.unicidade(df, "limites_stg", "id_cliente")
    assert resultado.aprovado is False
    assert resultado.severidade == "critica"
    assert quality.houve_falha_critica([resultado]) is True


def test_quality_gate_aprova_dado_valido(spark):
    from pipeline import quality

    df = spark.createDataFrame([("CLI1",), ("CLI2",)], "id_cliente string")
    resultados = [quality.unicidade(df, "limites_stg", "id_cliente")]
    assert quality.houve_falha_critica(resultados) is False


def test_ecl_e_rwa():
    e = Exposicao("CLI1", ead=100_000, pd=0.02, lgd=LGD_PADRAO)
    assert e.ecl == pytest.approx(900.00, abs=0.01)
    assert e.rwa == 100_000
    total = calcular([e])
    assert total["ecl_total"] == pytest.approx(900.00, abs=0.01)
    assert total["capital_requerido"] == pytest.approx(500.00, abs=0.01)  # 0,5% de 100k


def test_valor_positivo_reprova(spark):
    from pipeline import quality

    df = spark.createDataFrame(
        [("PROP1", 1000.0), ("PROP2", 0.0)],
        "id_proposta string, valor_solicitado double",
    )
    resultado = quality.valores_positivos(df, "propostas_stg", ["valor_solicitado"])[0]
    assert resultado.aprovado is False
    assert resultado.severidade == "critica"
    assert quality.houve_falha_critica([resultado]) is True


def test_resultado_do_gate_sobrevive_ao_csv(tmp_path):
    """A observacao contem virgula; sem o modulo csv a linha voltaria quebrada."""
    from pipeline import quality

    original = quality.Resultado(
        regra="faixa_numerica",
        tabela="limites_stg",
        coluna="limite_atribuido",
        severidade="alerta",
        aprovado=False,
        observacao="esperado [0, 5000000], 3 fora da faixa",
    )
    destino = tmp_path / "resultado_validacoes.csv"
    quality.gravar_resultado([original], destino)

    lidos = quality.ler_resultados(destino)
    assert len(lidos) == 1
    assert lidos[0].observacao == original.observacao
    assert lidos[0].aprovado is False
    assert lidos[0].severidade == "alerta"


def test_gravacao_sem_particionamento(spark, tmp_path):
    """Sem coluna de particionamento, o Spark nao pode receber partitionBy(None)."""
    from pipeline import load

    df = spark.createDataFrame([("CLI1", 0.021)], "id_cliente string, pd_12m double")
    destino = load.gravar(df, tmp_path / "scorecard", particionar_por=None)

    assert destino.exists()
    assert spark.read.parquet(str(destino)).count() == 1
