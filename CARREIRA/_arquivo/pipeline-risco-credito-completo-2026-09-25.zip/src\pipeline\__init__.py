"""Pipeline de dados de Risco de Credito (bronze -> silver -> quality gate -> gold)."""
