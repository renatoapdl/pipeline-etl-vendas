"""Camada gold (serve): gravacao particionada e idempotente.

Gravacao em Parquet particionado por dt_carga (data da carga, no formato AAAA-MM-DD).
Idempotencia: o modo overwrite substitui apenas o conteudo do caminho de destino, entao
reprocessar a mesma data nao duplica registro.
"""
from __future__ import annotations

from pathlib import Path

from pyspark.sql import DataFrame


def gravar(
    df: DataFrame,
    destino: Path,
    formato: str = "parquet",
    modo: str = "overwrite",
    particionar_por: str | list[str] | None = "dt_carga",
) -> Path:
    """Grava o DataFrame no destino e devolve o caminho final.

    O partitionBy so e chamado quando existe coluna de particionamento. Passar None para
    partitionBy faz o Spark receber uma coluna nula e derruba a escrita com NPE em
    PartitioningUtils.validatePartitionColumn.
    """
    destino.parent.mkdir(parents=True, exist_ok=True)
    colunas = [particionar_por] if isinstance(particionar_por, str) else list(particionar_por or [])

    escritor = df.write.mode(modo).format(formato).option("overwriteSchema", "true")
    if colunas:
        escritor = escritor.partitionBy(*colunas)
    escritor.save(str(destino))
    return destino


def gravar_sql(
    df: DataFrame,
    url: str,
    tabela: str,
    propriedades: dict[str, str] | None = None,
    modo: str = "append",
) -> None:
    """Escrita em banco relacional ou data warehouse (Postgres, MySQL, Snowflake).

    O padrao e append: sobrescrever tabela inteira em producao exige MERGE ou chave
    idempotente, nao apenas o modo overwrite.

    Exemplo:
        gravar_sql(
            df,
            "jdbc:postgresql://localhost:5432/risco_credito",
            "credito.exposicao",
            {"user": "pipeline", "password": "segredo"},
        )
    """
    escritor = df.write.mode(modo).format("jdbc").option("url", url).option("dbtable", tabela)
    for chave, valor in (propriedades or {}).items():
        escritor = escritor.option(chave, valor)
    escritor.save()
