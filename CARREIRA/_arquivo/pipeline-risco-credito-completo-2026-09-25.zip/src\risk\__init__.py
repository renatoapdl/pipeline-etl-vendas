"""Calculos de risco de credito (PD, EAD, LGD, ECL, RWA)."""
