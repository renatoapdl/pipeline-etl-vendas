"""DAG do pipeline de Risco de Credito.

Orquestra uma camada por tarefa, na ordem em que a dependencia existe de verdade:

    bronze_landing -> silver_staging -> quality_gate_dados -> checar_quality_gate -> gold_serve

Duas decisoes que valem explicar em entrevista:

1. O alerta de falha nao usa on_failure_email: essa API foi removida no Airflow 2. O
   callback abaixo registra em log e, se SMTP_HOST estiver definido, manda e-mail com smtplib.
   Sem provider extra e sem depender de API depreciada.

2. O quality gate e um artefato em disco (data/quality/resultado_validacoes.csv), nao um
   retorno de funcao. A tarefa checar_quality_gate roda em outro processo e le esse CSV,
   o mesmo arquivo que --camada publicar le antes de gravar a gold. Se o gate reprovar, a
   publicacao nem chega a rodar.

Limitacao conhecida: silver e quality leem a camada inteira do Parquet, sem filtrar pela
data de referencia. Num ambiente com historico longo isso entraria como filtro de particao
por dt_carga em cada leitura.

Deploy local: docker compose up -d e abrir http://localhost:8080
"""
from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.utils.trigger_rule import TriggerRule

log = logging.getLogger(__name__)

SPARK_SUBMIT = os.getenv("SPARK_SUBMIT", "spark-submit")
SPARK_MASTER = os.getenv("SPARK_MASTER", "")
PROJETO = os.getenv("PROJETO_DIR", "/opt/airflow/pipeline-risco-credito")


def _caminho_resultado() -> Path:
    """Resolvido na chamada, nao no import, para o caminho poder ser sobrescrito por execucao."""
    return Path(
        os.getenv("RESULTADO_VALIDACOES", f"{PROJETO}/data/quality/resultado_validacoes.csv")
    )


def _cmd(camada: str, data_referencia: str | None = None) -> str:
    partes = [f'cd "{PROJETO}" && {SPARK_SUBMIT}']
    if SPARK_MASTER:
        partes.append(f"--master {SPARK_MASTER}")
    partes.append(f"src/pipeline/run_pipeline.py --camada {camada}")
    if data_referencia:
        partes.append(f"--data-referencia {data_referencia}")
    return " ".join(partes)


def _checa_gate(**contexto) -> None:
    """Le o resultado do quality gate e interrompe a DAG se houver falha critica."""
    sys.path.insert(0, str(Path(PROJETO) / "src"))
    from pipeline.quality import houve_falha_critica, ler_resultados  # type: ignore

    resultados = ler_resultados(_caminho_resultado())
    reprovados = [r for r in resultados if r.severidade == "critica" and not r.aprovado]
    log.info("Quality gate: %d regras, %d reprovadas", len(resultados), len(reprovados))
    if houve_falha_critica(resultados):
        raise ValueError(
            "Quality gate reprovou: "
            + ", ".join(f"{r.coluna} ({r.observacao})" for r in reprovados)
        )


def _alerta_falha(contexto) -> None:
    """Registra a falha e, se SMTP_HOST existir, envia e-mail sem usar API depreciada."""
    dag_run = contexto.get("dag_run")
    tarefa = contexto.get("task_instance")
    log.error(
        "Tarefa %s da DAG %s falhou na execucao %s",
        getattr(tarefa, "task_id", "?"),
        getattr(dag_run, "dag_id", "?"),
        getattr(dag_run, "run_id", "?"),
    )

    if not os.getenv("SMTP_HOST"):
        return

    try:
        import smtplib
        from email.message import EmailMessage

        mensagem = EmailMessage()
        mensagem["Subject"] = f"[AIRFLOW] Falha em {getattr(dag_run, 'dag_id', '?')}"
        mensagem["From"] = os.getenv("SMTP_FROM", "airflow@localhost")
        mensagem["To"] = os.getenv("SMTP_DESTINO", "dados@localhost")
        mensagem.set_content(f"Tarefa {getattr(tarefa, 'task_id', '?')} falhou. Ver log do Airflow.")
        with smtplib.SMTP(os.environ["SMTP_HOST"], int(os.getenv("SMTP_PORTA", "25"))) as smtp:
            smtp.send_message(mensagem)
    except Exception:  # noqa: BLE001 - alerta nunca pode derrubar o alerta
        log.exception("Falha ao enviar o e-mail de alerta")


default_args = {
    "owner": "renatoapdl",
    "depends_on_past": False,
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
    "on_failure_callback": _alerta_falha,
}

with DAG(
    dag_id="etl_risco_credito",
    description="Pipeline ETL de Risco de Credito: bronze -> silver -> quality gate -> gold",
    schedule="0 6 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    default_args=default_args,
    tags=["dados", "risco-de-credito", "spark"],
) as dag:
    extrair = BashOperator(
        task_id="bronze_landing",
        bash_command=_cmd("bronze", "{{ ds }}"),
        doc_md="Le as fontes como chegaram e registra metadados de carga. "
               "Em backfill, a data logica da execucao vira a data da carga.",
    )

    tratar = BashOperator(
        task_id="silver_staging",
        bash_command=_cmd("silver"),
        doc_md="Limpeza, nulos, deduplicacao e campos derivados.",
    )

    medir = BashOperator(
        task_id="quality_gate_dados",
        bash_command=_cmd("quality"),
        doc_md="Executa as regras e grava o resultado em data/quality/resultado_validacoes.csv.",
    )

    validar = PythonOperator(
        task_id="checar_quality_gate",
        python_callable=_checa_gate,
        doc_md="Reprova a carga se alguma regra critica falhar.",
    )

    publicar = BashOperator(
        task_id="gold_serve",
        bash_command=_cmd("publicar"),
        trigger_rule=TriggerRule.ALL_SUCCESS,
        doc_md="Publica a camada de exposicao de credito para consumo.",
    )

    extrair >> tratar >> medir >> validar >> publicar
