-- Consultas analiticas para a camada gold.
-- Foco em SQL que o interviewer pede: CTE, window function, upsert, otimizacao.

-- 1. Exposicao por cliente com ranking de uso do limite (window function)
WITH exposicao AS (
    SELECT
        id_cliente,
        segmento,
        limite_atribuido,
        faturamento_anual,
        uso_limite,
        cliente_ativo
    FROM gold_exposicao_credito
    WHERE cliente_ativo = 1
),
classificado AS (
    SELECT
        segmento,
        limite_atribuido,
        uso_limite,
        -- percentil do cliente dentro do proprio segmento
        PERCENT_RANK() OVER (PARTITION BY segmento ORDER BY uso_limite DESC) AS pct_em_uso
    FROM exposicao
)
SELECT
    segmento,
    COUNT(*)                                  AS qt_clientes,
    ROUND(AVG(limite_atribuido), 2)           AS limite_medio,
    ROUND(AVG(uso_limite), 4)                 AS uso_medio,
    SUM(CASE WHEN pct_em_uso <= 0.10 THEN 1 ELSE 0 END) AS clientes_top10pct
FROM classificado
GROUP BY segmento
ORDER BY limite_medio DESC;


-- 2. Concentracao de risco: quanto do limite total cada cliente representa
SELECT
    id_cliente,
    limite_atribuido,
    ROUND(
        limite_atribuido * 100.0 / SUM(limite_atribuido) OVER (),
        4
    ) AS pct_do_total
FROM gold_exposicao_credito
WHERE limite_atribuido > 0
ORDER BY limite_atribuido DESC
LIMIT 50;


-- 3. Movimentacao mensal por segmento (soma movel de 3 meses)
SELECT
    mes,
    segmento,
    limite_atribuido,
    SUM(limite_atribuido) OVER (
        PARTITION BY segmento ORDER BY mes ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ) AS limite_acumulado_3m
FROM (
    SELECT
        DATE_TRUNC('month', data_avaliacao) AS mes,
        segmento,
        SUM(limite_atribuido)               AS limite_atribuido
    FROM silver_limites_stg
    GROUP BY DATE_TRUNC('month', data_avaliacao), segmento
) t
ORDER BY mes, segmento;


-- 4. Upsert idempotente: atualiza sem duplicar, chave (id_cliente, dt_carga)
MERGE INTO gold_exposicao_credito AS alvo
USING (
    SELECT * FROM silver_exposicao_stg WHERE dt_carga = DATE '2026-09-25'
) AS origem
ON  alvo.id_cliente = origem.id_cliente
AND alvo.dt_carga    = origem.dt_carga
WHEN MATCHED THEN UPDATE SET
    limite_atribuido = origem.limite_atribuido,
    uso_limite       = origem.uso_limite,
    cliente_ativo    = origem.cliente_ativo
WHEN NOT MATCHED THEN INSERT (id_cliente, dt_carga, limite_atribuido, uso_limite, cliente_ativo)
    VALUES (origem.id_cliente, origem.dt_carga, origem.limite_atribuido, origem.uso_limite, origem.cliente_ativo);


-- 5. Deteccao de anomalia: cliente cujo limite mudou mais de 50% entre avaliacoes
WITH variacao AS (
    SELECT
        id_cliente,
        limite_atribuido,
        LAG(limite_atribuido) OVER (PARTITION BY id_cliente ORDER BY data_avaliacao) AS limite_anterior
    FROM silver_limites_stg
)
SELECT
    id_cliente,
    limite_anterior,
    limite_atribuido,
    ROUND((limite_atribuido - limite_anterior) * 100.0 / NULLIF(limite_anterior, 0), 2) AS variacao_pct
FROM variacao
WHERE limite_anterior IS NOT NULL
  AND ABS(limite_atribuido - limite_anterior) * 1.0 / NULLIF(limite_anterior, 0) > 0.5
ORDER BY variacao_pct DESC;


-- 6. Consulta otimizada: filtro de particao antes da agregacao
-- Sem o filtro por dt_carga o Spark le todas as particoes do historico.
SELECT COUNT(*) AS qt_registros
FROM gold_exposicao_credito
WHERE dt_carga = DATE '2026-09-25'
  AND cliente_ativo = 1;
