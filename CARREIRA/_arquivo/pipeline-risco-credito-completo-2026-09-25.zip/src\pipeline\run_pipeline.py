"""Executor do pipeline por camadas.

Cada camada le da camada anterior o Parquet gravado em disco, e nao da memoria do processo.
E assim que roda num ambiente real: qualquer etapa pode ser reprocessada sozinha, em outra
data e por outra maquina, e a DAG do Airflow consegue orquestrar uma camada por tarefa.

Uso:
  spark-submit src/pipeline/run_pipeline.py --camada bronze    [--data-referencia AAAA-MM-DD]
  spark-submit src/pipeline/run_pipeline.py --camada silver
  spark-submit src/pipeline/run_pipeline.py --camada quality
  spark-submit src/pipeline/run_pipeline.py --camada publicar
  spark-submit src/pipeline/run_pipeline.py --camada todas     [--data-referencia AAAA-MM-DD]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline import extract, load, quality, transform  # noqa: E402
from pipeline.spark_session import OUTPUT_PATH, get_spark  # noqa: E402

SITUACOES = ["aprovada", "recusada", "em_analise", "desconhecida"]
CAMADAS_COM_DATA = {"bronze", "todas"}


def _bronze(nome: str) -> Path:
    return OUTPUT_PATH / "bronze" / nome


def _silver(nome: str) -> Path:
    return OUTPUT_PATH / "silver" / nome


def _ler(spark, caminho: Path):
    if not caminho.exists():
        raise SystemExit(f"Camada ausente: {caminho}. Rode a camada anterior antes desta.")
    return spark.read.parquet(str(caminho))


def camada_bronze(spark, data_referencia: str | None = None) -> Path:
    """Landing: le as fontes como chegaram e grava Parquet particionado por dt_carga."""
    fontes = (
        ("clientes", extract.ler_clientes(spark, data_referencia=data_referencia)),
        ("propostas", extract.ler_propostas(spark, data_referencia=data_referencia)),
        ("limites", extract.ler_limites(spark, data_referencia=data_referencia)),
        ("scorecard", extract.ler_scorecard(spark, data_referencia=data_referencia)),
    )
    for nome, df in fontes:
        # scorecard nao e particionado: e uma base pequena, consultada por id_cliente
        load.gravar(df, _bronze(nome), particionar_por=None if nome == "scorecard" else "dt_carga")
    return OUTPUT_PATH / "bronze"


def camada_silver(spark) -> Path:
    """Staging: limpeza, padronizacao, nulos, deduplicacao e campos derivados."""
    clientes = transform.normalizar_clientes(_ler(spark, _bronze("clientes")))
    propostas = transform.normalizar_propostas(_ler(spark, _bronze("propostas")))
    limites = transform.normalizar_limites(_ler(spark, _bronze("limites")))

    load.gravar(clientes, _silver("clientes_stg"))
    load.gravar(propostas, _silver("propostas_stg"))
    load.gravar(limites, _silver("limites_stg"))
    return OUTPUT_PATH / "silver"


def camada_quality(spark) -> list[quality.Resultado]:
    """Quality gate: valida a silver e grava o resultado que a publicacao vai ler."""
    clientes = _ler(spark, _silver("clientes_stg"))
    propostas = _ler(spark, _silver("propostas_stg"))
    limites = _ler(spark, _silver("limites_stg"))
    limites_bronze = _ler(spark, _bronze("limites"))

    resultados = [
        *quality.nao_nulos(clientes, "clientes_stg", ["id_cliente", "segmento"]),
        *quality.nao_nulos(propostas, "propostas_stg", ["id_proposta", "id_cliente", "situacao_padrao"]),
        *quality.nao_nulos(limites, "limites_stg", ["id_cliente", "limite_atribuido"]),
        *quality.valores_positivos(propostas, "propostas_stg", ["valor_solicitado", "prazo_meses"]),
        quality.valores_dentro_do_dominio(propostas, "propostas_stg", "situacao_padrao", SITUACOES),
        quality.faixa_numerica(limites, "limites_stg", "limite_atribuido", 0, 5_000_000),
        quality.unicidade(limites_bronze, "limites_brz", "id_cliente", severidade="alerta"),
    ]

    quality.gravar_resultado(resultados, OUTPUT_PATH / "quality" / "resultado_validacoes.csv")
    quality.profiling(clientes, "clientes_stg").coalesce(1).write.mode("overwrite") \
        .option("header", True).csv(str(OUTPUT_PATH / "quality" / "relatorio_profiling"))

    for resultado in resultados:
        marca = "ok   " if resultado.aprovado else "FALHA"
        print(f"[{marca}] {resultado.severidade:7} {resultado.regra:18} {resultado.coluna:18} {resultado.observacao}")
    return resultados


def camada_gold(spark) -> Path:
    """Publica a exposicao de credito somente se o quality gate passou."""
    resultados = quality.ler_resultados(OUTPUT_PATH / "quality" / "resultado_validacoes.csv")
    reprovados = [r for r in resultados if r.severidade == "critica" and not r.aprovado]
    if reprovados:
        raise SystemExit(
            "Quality gate reprovou, camada gold nao publicada: "
            + ", ".join(f"{r.coluna} ({r.observacao})" for r in reprovados)
        )

    exposicao = transform.criar_campos_derivados(
        _ler(spark, _silver("clientes_stg")),
        _ler(spark, _silver("propostas_stg")),
        _ler(spark, _silver("limites_stg")),
    )
    return load.gravar(exposicao, OUTPUT_PATH / "gold" / "exposicao_credito")


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Pipeline de risco de credito: bronze -> silver -> quality -> gold"
    )
    ap.add_argument("--camada", required=True,
                    choices=["bronze", "silver", "quality", "publicar", "todas"])
    ap.add_argument("--data-referencia", metavar="AAAA-MM-DD",
                    help="Data da carga no bronze (default: hoje). Vale so para bronze e todas.")
    args = ap.parse_args()

    if args.data_referencia and args.camada not in CAMADAS_COM_DATA:
        ap.error("--data-referencia so vale para --camada bronze ou --camada todas")

    spark = get_spark()
    try:
        if args.camada in ("bronze", "todas"):
            print(f"bronze gravada em {camada_bronze(spark, args.data_referencia)}")
        if args.camada in ("silver", "todas"):
            print(f"silver gravada em {camada_silver(spark)}")
        if args.camada in ("quality", "todas"):
            camada_quality(spark)
        if args.camada in ("publicar", "todas"):
            print(f"gold gravada em {camada_gold(spark)}")
    finally:
        spark.stop()


if __name__ == "__main__":
    main()
