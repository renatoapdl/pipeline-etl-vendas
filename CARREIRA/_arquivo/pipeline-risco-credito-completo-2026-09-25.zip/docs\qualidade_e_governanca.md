# Qualidade de dados e governança

## Regras implementadas

| Regra | Tipo | Tabela | Coluna | O que faz |
|-------|------|--------|--------|-----------|
| `nao_nulo` | crítica | clientes_stg, propostas_stg | chaves | Chave de negócio não pode ser nula |
| `dominio_controlado` | crítica | propostas_stg | situacao_padrao | Valor precisa estar no vocabulário definido |
| `unicidade` | crítica | limites_stg | id_cliente | Não pode haver duplicidade na chave de negócio |
| `faixa_numerica` | alerta | limites_stg | limite_atribuido | Valor fora da faixa não reprova, mas avisa |
| `profiling` | informação | todas | todas | Contagem, nulos, distintos, mínimo, máximo e média |

O resultado de cada execução fica em `data/quality/resultado_validacoes.csv` com nome da regra, tabela,
coluna, severidade e resultado. O perfil por coluna fica em `data/quality/relatorio_profiling/`.

## Por que o gate bloqueia a publicação

Em número de crédito, dado errado não gera apenas um relatório feio: gera decisão errada, e decisão errada em
ambiente regulado gera retrabalho. Por isso a regra crítica impede a camada gold de ser publicada e registra o
motivo. A regra de faixa numérica não bloqueia, mas fica registrada.

## Política de reprocesso

1. Reprocessar a mesma `dt_carga` **sobrescreve** a partição, porque a gravação é idempotente.
2. Reprocesso parcial: rodar `--camada silver` e depois `--camada quality`.
3. Alteração de regra de negócio exige novo commit, nova tag de versão e nova execução do gate.
4. Reprocesso que altera número já publicado exige registro de aprovação. O arquivo de resultado guarda a
   data da execução, mas o controle de aprovação é do processo do banco.

## Linhagem (o que a Resolução Bacen 4.966/21 pede)

A resolução exige que o número de risco seja rastreável até a origem, com regra documentada. Neste projeto isso
aparece em três pontos:

1. **Origem** — `origem` e `dt_carga` viajam com o dado em bronze, silver e gold.
2. **Regra** — o nome da regra é uma constante no código e vai para o relatório de validação.
3. **Versão** — mudança de regra é mudança de código, e o código está no Git com histórico.

O que falta para conformidade plena: catálogo de dados com glossário de negócio, classificação de dados
sensíveis, controle de acesso por papel e registro formal de aprovação. Fica documentado aqui como próximo
passo, não como conformidade.

## Como isso vira argumento em entrevista

Pergunta provável: *"como você garante que o número de risco está certo?"*

Resposta em três camadas:
1. **Prevenção** — regras de validação no pipeline, com gate que impede publicação.
2. **Detecção** — profiling por coluna e comparação com o período anterior.
3. **Rastreabilidade** — linhagem da regra até a origem, com versão do código e data de execução.
