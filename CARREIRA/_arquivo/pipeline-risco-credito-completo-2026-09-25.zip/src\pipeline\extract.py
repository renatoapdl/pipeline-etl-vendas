"""Camada bronze (landing): le as fontes como chegaram, sem alterar o conteudo.

O que entra aqui e apenas tipagem minima para o Parquet e metadados de carga.
Regra de ouro: bronze nao corrige dado, apenas registra.

A coluna dt_carga e a data da carga (AAAA-MM-DD) e serve de chave de particionamento. A
--data-referencia permite reprocessar uma data especifica, que e o que a DAG usa no backfill.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from pathlib import Path

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import lit

from .spark_session import INPUT_PATH


def _marca_carga(df: DataFrame, origem: str, data_referencia: str | None = None) -> DataFrame:
    if data_referencia:
        try:
            dia = date.fromisoformat(data_referencia)
        except ValueError:
            raise SystemExit(
                f"--data-referencia invalida: {data_referencia}. Use o formato AAAA-MM-DD."
            ) from None
        carregamento = datetime.combine(dia, datetime.min.time(), tzinfo=timezone.utc)
    else:
        carregamento = datetime.now(timezone.utc)

    return (
        df.withColumn("dt_carga", lit(carregamento.date().isoformat()))
        .withColumn("dt_carga_ts", lit(carregamento.isoformat(timespec="seconds")))
        .withColumn("origem", lit(origem))
    )


def _csv(spark: SparkSession, caminho: Path) -> DataFrame:
    return (
        spark.read.option("header", True)
        .option("inferSchema", True)
        .option("encoding", "UTF-8")
        .csv(str(caminho))
    )


def ler_clientes(
    spark: SparkSession, path: Path | None = None, data_referencia: str | None = None
) -> DataFrame:
    return _marca_carga(_csv(spark, path or INPUT_PATH / "clientes.csv"), "clientes.csv", data_referencia)


def ler_propostas(
    spark: SparkSession, path: Path | None = None, data_referencia: str | None = None
) -> DataFrame:
    return _marca_carga(_csv(spark, path or INPUT_PATH / "propostas.csv"), "propostas.csv", data_referencia)


def ler_limites(
    spark: SparkSession, path: Path | None = None, data_referencia: str | None = None
) -> DataFrame:
    return _marca_carga(_csv(spark, path or INPUT_PATH / "limites.csv"), "limites.csv", data_referencia)


def ler_scorecard(
    spark: SparkSession, path: Path | None = None, data_referencia: str | None = None
) -> DataFrame:
    """Scorecard vem de servico JSON (API interna), nao de arquivo tabular."""
    return _marca_carga(
        spark.read.option("multiLine", True).json(str(path or INPUT_PATH / "scorecard_base.json")),
        "scorecard_base.json",
        data_referencia,
    )
