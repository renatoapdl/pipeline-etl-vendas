# pipeline-risco-credito

Pipeline de dados em camadas (ELT/ETL) para uma base sintética de **Risco de Crédito**, construído para
demonstrar domínio prático da stack pedida em vagas de Engenharia de Dados: **Python, PySpark, SQL, Airflow,
Kubernetes e Snowflake**.

> **Aviso:** os dados aqui são **100% sintéticos**, gerados por script. Nada de dado real de cliente.
> O objetivo do repositório não é o negócio, é **provar execução**: dá para ler o código, rodar em 5 minutos
> e ver o resultado com qualidade validada.

---

## O que este repositório demonstra

| Competência | Onde está |
|-------------|-----------|
| Leitura de múltiplas fontes (CSV, JSON, Parquet) | `src/pipeline/extract.py` |
| Limpeza de dados, nulos e valor padrão, deduplicação | `src/pipeline/transform.py` |
| Criação de campos derivados a partir de um ou mais campos | `src/pipeline/transform.py` |
| Qualidade de dados: regras, validação e *profiling* | `src/pipeline/quality.py` |
| Gravação particionada em Parquet com metadados de carga | `src/pipeline/load.py` |
| Orquestração de DAG com *backfill* por data e alerta de falha | `dags/etl_risco_credito.py` |
| SQL analítico: CTE, *window function*, *upsert* | `sql/queries_analiticas.sql` |
| Conhecer o domínio: PD, EAD, LGD e provisão (IFRS 9) | `src/risk/provisoes.py` |
| Operar em Kubernetes: manifestos e comandos de dia a dia | `k8s/` e `docs/kubernetes_comandos.md` |
| Testes automatizados e CI que prova o quality gate | `tests/`, `.github/workflows/ci.yml` |

---

## Arquitetura (camadas, com quality gate)

```
raw/  ──►  bronze (landing)  ──►  silver (staging)  ──►  gold (serve)  ──►  consumo
              extração              limpeza              regras              dashboard/
              sem alterar           derivados            de negócio         scorecard
                                    qualidade            crédito
                                      │
                            QUALITY GATE  (reprova e bloqueia a publicação)
```

- **bronze / landing** — dados como chegaram, com metadados de carga (`dt_carga`, `dt_carga_ts`, `origem`).
- **silver / staging** — tipagem, padronização, nulos tratados, deduplicação, campos derivados.
- **gold / serve** — tabela de exposição de crédito pronta para consumo, com indicadores.
- **quality gate** — roda entre staging e publicação; se qualquer regra **crítica** falhar, a camada gold
  **não é gravada** e a DAG para.

**Cada camada lê da anterior o Parquet em disco**, não da memória do processo. É o que permite reprocessar
uma etapa sozinha, em outra data e por outra máquina — e é o que a DAG usa para ter uma camada por tarefa.

O resultado do gate é um artefato (`data/quality/resultado_validacoes.csv`). A publicação, que roda em outro
processo, lê esse arquivo antes de gravar. Se o gate reprovar, a publicação nem começa.

---

## Como rodar

### Requisitos

| Componente | Versão | Observação |
|-----------|---------|------------|
| Python | 3.9 a 3.12 | 3.13+ não é suportado pelo PySpark |
| Java | 17 ou 21 | com `JAVA_HOME` configurado |
| PySpark | 3.5.x | fixado em `requirements.txt` |
| Docker | opcional | para rodar a DAG do Airflow |

Dependências separadas de propósito: `requirements.txt` para o pipeline, `requirements-airflow.txt` para a
orquestração. O Airflow não é preciso para rodar o pipeline e conflita com o PySpark na instalação.

> **Rodando local no Windows:** o Hadoop exige o `winutils.exe` para escrever arquivos. Sem ele o erro é
> `HADOOP_HOME and hadoop.home.dir are unset`. Duas saídas: definir `HADOOP_HOME` apontando para uma pasta com
> `winutils.exe` (o [cdarlint/winutils](https://github.com/cdarlint/winutils), versão `hadoop-3.3.6`, resolve),
> ou rodar em container / Databricks, onde o problema não existe. Em Linux e macOS não há esse requisito.

> **Quirk do `spark-submit` no Windows:** o launcher instalado por `pip` (`Scripts\spark-submit.cmd`) descarta
> os argumentos passados — nem `--master` nem `--conf` chegam ao app. Se precisar de configuração de spark
> por linha de comando no Windows, use o container. O CI roda em Linux e não sofre com isso.

### Opção 1 — local

```bash
pip install -r requirements.txt
python data/gerar_dados_sinteticos.py --linhas 500      # gera a base sintética

spark-submit src/pipeline/run_pipeline.py --camada bronze
spark-submit src/pipeline/run_pipeline.py --camada silver
spark-submit src/pipeline/run_pipeline.py --camada quality
spark-submit src/pipeline/run_pipeline.py --camada publicar

# ou tudo de uma vez:
spark-submit src/pipeline/run_pipeline.py --camada todas
```

O bronze aceita `--data-referencia AAAA-MM-DD` para reprocessar uma data específica (é o que a DAG usa no
*backfill*). A publicação (`publicar`) é a única que não aceita a opção, porque reprocessa data antiga não
tem sentido para consumo.

### Opção 2 — testes

```bash
pip install pytest
pytest -v
```

Os 11 testes cobrem: nulos com valor padrão, deduplicação, campo derivado, divisão por zero, vocabulário
controlado, quality gate aprovando e reprovando, valor não positivo, ida e volta do resultado do gate em CSV
(a observação contém vírgula e voltaria quebrada sem o módulo `csv`), gravação sem particionamento e o
cálculo de ECL/RWA.

### Opção 3 — DAG do Airflow com Docker

```bash
docker compose up -d
# Airflow em http://localhost:8080  (usuário: airflow / senha: airflow)
# DAG: etl_risco_credito
```

A imagem do Airflow é construída a partir de `Dockerfile.airflow`, que adiciona JDK e PySpark — a imagem
oficial do Airflow não tem `spark-submit`, então a DAG não conseguiria disparar o Spark sem isso.

Para receber alerta por e-mail, preencha `SMTP_HOST`, `SMTP_PORTA`, `SMTP_FROM` e `SMTP_DESTINO` no
`docker-compose.yml`. Sem `SMTP_HOST`, a falha fica só no log.

### Opção 4 — cluster de estudo (Databricks Community Edition, grátis)

Criar conta em databricks.com, subir um cluster e importar `src/pipeline/` como job, apontando
`INPUT_PATH` para `data/raw/`.

### Opção 5 — Kubernetes

```bash
docker build -t ghcr.io/SEU_USUARIO/pipeline-risco-credito:1.0.0 .
docker push ghcr.io/SEU_USUARIO/pipeline-risco-credito:1.0.0
# trocar a tag nos manifestos e:
kubectl apply -f k8s/
kubectl logs job/pipeline-risco-credito-spark -f
```

O Job usa `--master k8s://` com `--deploy-mode cluster`, e o `SPARK_MASTER` fica **fora** do ConfigMap de
propósito: se estivesse lá, o `SparkSession.builder` sobrescreveria o master do cluster e o Job rodaria
`local[*]` dentro do driver, sem pedir executor.

---

## Saída esperada

```
data/
├── raw/        clientes.csv, propostas.csv, limites.csv, scorecard_base.json
├── bronze/     clientes/, propostas/, limites/, scorecard/   (Parquet; scorecard sem partição)
├── silver/     clientes_stg/, propostas_stg/, limites_stg/
├── quality/    resultado_validacoes.csv, relatorio_profiling/
└── gold/       exposicao_credito/dt_carga=AAAA-MM-DD/       (Parquet)
```

O resultado do gate sai assim (a observação com vírgula vem entre aspas, porque foi escrita com o módulo `csv`):

```csv
regra,tabela,coluna,severidade,aprovado,observacao,executado_em
nao_nulo,clientes_stg,segmento,critica,true,0 nulos,2026-09-25T18:00:20+00:00
valor_positivo,propostas_stg,valor_solicitado,critica,true,0 valores menores ou iguais a zero,2026-09-25T18:00:20+00:00
faixa_numerica,limites_stg,limite_atribuido,alerta,true,"esperado [0, 5000000], 0 fora da faixa",2026-09-25T18:00:20+00:00
unicidade,limites_brz,id_cliente,alerta,true,"400 linhas, 400 distintos, 0 duplicadas",2026-09-25T18:00:20+00:00
```

Para ver o gate **reprovando**: acrescente uma linha com `valor_solicitado` = 0 em `data/raw/propostas.csv` e
rode `--camada publicar`. A publicação sai com código 1 e o `data/gold/` não é criado. É o que o CI faz.

---

## Decisões de engenharia (o porquê de cada uma)

| Decisão | Motivo |
|---------|--------|
| Parquet particionado por `dt_carga` | formato colunar, compressão e *partition pruning* em consulta |
| Idempotência por chave de negócio + `dt_carga` | reprocessar a mesma data não duplica registro |
| Campos derivados versionados no código | regra de negócio auditável, requisito de governança |
| Quality gate antes da camada gold | dado errado publicado em crédito custa caro; a regra é o controle |
| Metadados de carga em toda camada | rastreabilidade exigida em ambiente regulado (Res. Bacen 4.966/21) |
| Leitura tolerante a esquema (`inferSchema` + cast explícito) | fonte de origem externa muda de formato sem aviso |

---

## Governança e Bacen 4.966/21

A resolução exige rastreabilidade e documentação das regras usadas para gerar números de risco. Neste
repositório isso aparece como:
- **linhagem** registrada em `data/quality/resultado_validacoes.csv` (regra, tabela, coluna, data, versão);
- **versionamento** das regras de transformação no código (tag de release por mudança de regra);
- **política de reprocesso** documentada em `docs/qualidade_e_governanca.md`.

Não é um atendimento completo da norma — é a demonstração de que o processo foi pensado para ela.

---

## Bugs que esse repositório já pegou

Rodar de verdade é o que acha o que revisão de código não acha. Estes foram encontrados executando:

| Sintoma | Causa |
|---------|-------|
| `NPE` em `PartitioningUtils` ao gravar | `partitionBy(None)` enviava uma coluna nula ao Spark |
| `Reference dt_carga is ambiguous` no join da gold | as colunas de auditoria vinham duplicadas da bronze |
| `avg(data_abertura)` rejeitado no *profiling* | `avg` em coluna `DATE`; agora a medida depende do tipo |
| `F.union` inexistente | `union` é método do `DataFrame`, não função de coluna |
| `WinError 10038` / `HADOOP_HOME unset` | PySpark 4 sem Windows e Hadoop sem `winutils` |
| `--master` do `spark-submit` ignorado | `.master()` no builder sobrescrevia o launcher; o `Job` do k8s rodaria `local[*]` |
| CSV do gate voltando quebrado | observação com vírgula quebrava a linha na volta; passou a usar o módulo `csv` |
| DAG nem carregava no Airflow 2.9 | `send_failure_email` foi removido no Airflow 2 |

---

## Próximos passos (roadmap deste repositório)

- [x] Testes unitários das regras de transformação (`tests/`)
- [x] DAG com *backfill* parametrizado por data
- [x] Quality gate que bloqueia a publicação de verdade (comprovado no CI)
- [ ] Painel de consumo (Power BI ou Streamlit) sobre a camada gold
- [ ] Monitoramento de *drift* do scorecard (MLOps)
- [ ] Versão em Snowflake (criar schema, tabela e *view*)

---

## Autor

**Francisco Renato Abreu** — Engenheiro Eletricista, Engenheiro de Dados em transição.
14 anos de operação de infraestrutura crítica (rede IVS-NASA) e Python em produção para telemetria.

- LinkedIn: linkedin.com/in/renatoabreuengenharia
- GitHub: github.com/renatoapdl
