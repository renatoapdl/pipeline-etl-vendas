# Kubernetes — comandos do dia a dia

Referência rápida dos comandos que aparecem em entrevista e no dia a dia com Spark no cluster.

> **Status honesto:** estes comandos ainda **não foram executados** contra um cluster. Os manifestos de `k8s/`
> são coerentes e revisados, mas só foram validados até a verificação de sintaxe do YAML. Para fechar isso é
> preciso subir um cluster local (`minikube start` ou `kind create cluster`), apontar a tag da imagem nos
> manifestos, aplicar e colar aqui a saída real de cada comando.

## Contexto e recursos

```bash
kubectl config current-context          # qual cluster estou usando
kubectl get nodes -o wide               # nos e recursos
kubectl get pods -A                     # todos os pods de todos os namespaces
kubectl get pods -w                     # acompanha em tempo real
```

## Descrever um pod (primeiro passo de debugging)

```bash
kubectl describe pod <pod>              # eventos, restart count, volumes, node
kubectl get pod <pod> -o yaml           # manifesto efetivo
kubectl logs <pod>                      # log do container principal
kubectl logs -f <pod>                   # acompanha o log
kubectl logs <pod> --previous           # log do container anterior (depois de crash)
```

## Entrar no pod e executar comandos

```bash
kubectl exec -it <pod> -- bash
kubectl exec -it <pod> -- spark-submit --version
kubectl cp <pod>:/opt/pipeline-risco-credito/data/quality/resultado_validacoes.csv ./resultado.csv
```

## Rede e portas

```bash
kubectl port-forward pod/<pod> 8080:8080   # acesso local ao servico do pod
kubectl get svc                            # servicos e portas
kubectl describe svc <svc>                 # selector e endpoints
```

## Escala, recursos e saúde

```bash
kubectl top pods                          # consumo de CPU e memória
kubectl get hpa                           # autoscaling configurado
kubectl scale deployment/<dep> --replicas=3
kubectl get events --sort-by=.lastTimestamp | tail -20
```

## Logs e depuração em lote

```bash
kubectl logs -l app=pipeline-risco-credito --all-containers --prefix
kubectl get pods -l app=pipeline-risco-credito -o wide
```

## Aplicar os manifestos deste projeto

```bash
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/job-spark.yaml
kubectl get jobs
kubectl logs -f job/pipeline-risco-credito-spark
```

## Erros que aparecem em entrevista

| Sintoma | Causa comum | Comando |
|---------|-------------|---------|
| `ImagePullBackOff` | tag de imagem inexistente | `kubectl describe pod` e ver a linha `Failed to pull image` |
| `CrashLoopBackOff` | processo morre na inicialização | `kubectl logs <pod> --previous` |
| `OOMKilled` | memória do container acima do limite | `kubectl describe pod` e ajustar `memory` ou `executor.memory` |
| `Pending` | sem nó com CPU/memória suficiente | `kubectl describe pod` e ver `Insufficient cpu` |
| Pod `Terminating` infinito | *finalizer* ou volume não desmonta | `kubectl get pod -o yaml` e ver `finalizers` |

> **Print de tela de cada comando** é o que prova a familiaridade com a ferramenta. Este documento existe para
> ser preenchido com os prints reais.
