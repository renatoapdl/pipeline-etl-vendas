# Arquitetura do pipeline

## Visão geral

```mermaid
flowchart LR
    subgraph Fontes
        C[clientes.csv]
        P[propostas.csv]
        L[limites.csv]
        S[scorecard_base.json]
    end

    subgraph Bronze
        B1[(clientes)]
        B2[(propostas)]
        B3[(limites)]
    end

    subgraph Silver
        S1[clientes_stg]
        S2[propostas_stg]
        S3[limites_stg]
    end

    Q{{Quality Gate}}
    G[(gold_exposicao_credito)]
    D[dashboard / scorecard]

    C --> B1
    P --> B2
    L --> B3
    S --> B1
    B1 --> S1
    B2 --> S2
    B3 --> S3
    S1 --> Q
    S2 --> Q
    S3 --> Q
    Q -->|aprovado| G
    Q -->|reprovado| F[alerta + log de reprovacao]
    G --> D
```

## Por que camadas

| Camada | Quem consome | Pode ser reprocessada | Contém dado bruto |
|--------|--------------|-----------------------|-------------------|
| bronze | engenharia de dados | sim, é a fonte da verdade do lote | sim |
| silver | analytics e regras de negócio | sim, é determinística | não |
| gold | dashboards, scorecard, modelo | sim, é derivado | não |

## Decisões de projeto

**Leitura tolerante a esquema.** As fontes são externas e mudam de formato sem aviso. O `extract` faz
`inferSchema` e o `transform` aplica cast explícito, para que a falha apareça no quality gate e não no meio
da transformation.

**Metadados de carga em toda camada.** `dt_carga` e `origem` viajam com o dado. É o mínimo para responder
"de onde veio este número?" em auditoria — requisito de governança.

**Idempotência.** A gravação sobrescreve a partição do lote. Reprocessar a mesma data não duplica linha, o que
permite *backfill* sem correção manual.

**Quality gate antes do gold.** Publicar número de crédito errado custa caro e gera retrabalho regulatório.
Por isso a regra crítica bloqueia a publicação, e o log de validação fica versionado junto do dado.

**Separação entre regra e dado.** As regras de transformação são constantes no código (`REGRA_NULO`,
`DERIVADO_USO_LIMITE`), e o resultado do gate grava regra, tabela, coluna, severidade e observação
(`data/quality/resultado_validacoes.csv`). A amarração entre a versão da regra e a carga é o commit do código
que rodou, não uma coluna: em produção isso viraria uma tabela de versão de regra (`regra_id`, `versao`,
`vigencia_de`) referenciada pela carga. É a linha de base da linhagem exigida pela Resolução Bacen 4.966/21.
