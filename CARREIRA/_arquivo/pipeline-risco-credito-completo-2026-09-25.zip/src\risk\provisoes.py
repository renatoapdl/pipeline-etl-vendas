"""Risco de credito: calculo didatico de provisiao (IFRS 9 / Basel simplificado).

Nao e implementacao de producao nem consultoria de risco. E o equivalente em Python das
formulas que aparecem em entrevista, para demonstrar que o dominio foi estudado.

Referencias:
  PD   probability of default   -- probabilidade de inadimplencia em 12 meses
  EAD  exposure at default      -- valor exposto no evento de default
  LGD  loss given default       -- perda esperada dado o default (1 - recuperacao)
  RWA  risk weighted assets      -- EAD ponderada pelo capital
  ECL  expected credit loss     = PD x LGD x EAD
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

LGD_PADRAO = 0.45  # recuperacao de 55% com garantia de imovel
CAREGERAL_MINIMO = 0.005  # piso de capital de 0,5% (Basel III, classe lastro)


@dataclass
class Exposicao:
    id_cliente: str
    ead: float
    pd: float
    lgd: float = LGD_PADRAO
    collateral: float = 0.0

    @property
    def ead_liquida(self) -> float:
        return max(self.ead - self.collateral, 0.0)

    @property
    def ecl(self) -> float:
        return self.pd * self.lgd * self.ead_liquida

    @property
    def rwa(self) -> float:
        """Peso de risco de 100% para varejo, ajustado por colateral (simplificado)."""
        return self.ead_liquida

    @property
    def capital_requerido(self) -> float:
        return max(self.rwa * CAREGERAL_MINIMO, 0.0)


def calcular(exposicoes: list[Exposicao]) -> dict:
    ecl = sum(e.ecl for e in exposicoes)
    ead_total = sum(e.ead for e in exposicoes)
    return {
        "ead_total": ead_total,
        "ecl_total": ecl,
        "ecl_percentual": ecl / ead_total if ead_total else 0.0,
        "rwa_total": sum(e.rwa for e in exposicoes),
        "capital_requerido": sum(e.capital_requerido for e in exposicoes),
    }


def serie_temporal(propostas: list[dict]) -> list[dict]:
    """Provisao por mes: soma de ECL agrupada por mes de referencia."""
    por_mes: dict[str, float] = {}
    for p in propostas:
        mes = p.get("mes_referencia", "2025-01")
        pd_ = float(p.get("pd_12m", 0.0))
        ead = float(p.get("ead", 0.0))
        por_mes[mes] = por_mes.get(mes, 0.0) + pd_ * LGD_PADRAO * ead
    return [{"mes": m, "ecl": round(v, 2)} for m, v in sorted(por_mes.items())]


def exportar(exposicoes: list[Exposicao], caminho: Path) -> Path:
    caminho.parent.mkdir(parents=True, exist_ok=True)
    with caminho.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id_cliente", "ead", "pd", "lgd", "collateral", "ead_liquida", "ecl", "rwa", "capital"])
        for e in exposicoes:
            w.writerow([
                e.id_cliente, round(e.ead, 2), e.pd, e.lgd, e.collateral,
                round(e.ead_liquida, 2), round(e.ecl, 2), round(e.rwa, 2),
                round(e.capital_requerido, 2),
            ])
    return caminho


if __name__ == "__main__":
    exemplo = [
        Exposicao("CLI000001", 250_000, 0.031),
        Exposicao("CLI000002", 80_000, 0.120, collateral=20_000),
        Exposicao("CLI000003", 1_200_000, 0.008),
    ]
    resultado = calcular(exemplo)
    for chave, valor in resultado.items():
        print(f"{chave}: {valor:,.2f}")
    print(f"\nserie: {serie_temporal([{'mes_referencia': '2025-07', 'pd_12m': 0.02, 'ead': 100000}])}")
