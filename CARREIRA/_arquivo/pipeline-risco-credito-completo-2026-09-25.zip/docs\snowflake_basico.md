# Snowflake — básico para o dia a dia

Snowflake é **SQL sobre armazenamento em nuvem**. Não tem servidor para gerenciar: o warehouse é provisionado
em segundos e cobra por tempo de COMPUTE, não por armazenamento. Isso muda a mentalidade de custo: warehouse
ligado gastando é desperdício.

## Conceitos (o mínimo)

| Conceito | O que é |
|----------|---------|
| Account | a conta, no topo |
| Database | agrupa schemas |
| Schema | agrupa tabelas e views (equivale ao schema do Postgres) |
| Table | guarda dados em colunas com micro-partições internas |
| Warehouse | cluster de COMPUTE que executa a query (também chamado de virtual warehouse) |
| Stage | área de arquivos (equivalente a S3/Azure Blob) |
| Role / Grant | permissão (padrão `ACCOUNTADMIN`, `SYSADMIN`, `USERADMIN`) |

## Criar o básico

```sql
CREATE DATABASE risco_credito;
USE DATABASE risco_credito;

CREATE SCHEMA bronze;
CREATE SCHEMA silver;
CREATE SCHEMA gold;

CREATE TABLE silver.limites_stg (
    id_cliente        VARCHAR,
    limite_atribuido  NUMBER(18,2),
    data_avaliacao    DATE,
    dt_carga          TIMESTAMP
);

CREATE OR REPLACE VIEW gold.exposicao_credito AS
SELECT
    id_cliente,
    limite_atribuido,
    dt_carga
FROM silver.limites_stg
WHERE limite_atribuido > 0;
```

## Warehouse

```sql
CREATE WAREHOUSE WH_RISCO
  WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 60          -- suspende após 60s sem uso
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE;

USE WAREHOUSE WH_RISCO;
SHOW WAREHOUSES;
```

## Carregar de um stage

```sql
LIST @raw_stage;                       -- lista arquivos no stage
COPY INTO bronze.propostas
  FROM @raw_stage/propostas.csv
  FILE_FORMAT = (TYPE = CSV SKIP_HEADER = 1);
```

## Particularidades que caem em entrevista

- **Maiúsculas viram minúsculas** em identificadores não delimitados. Use aspas para manter.
- **Não existe `INSERT ... SELECT` transacional como em banco comum**: o padrão é `CREATE OR REPLACE` ou
  `MERGE`. Por isso o `MERGE` de `sql/queries_analiticas.sql` é o caminho certo para upsert idempotente.
- **Time travel**: `SELECT * FROM tabela AT (TIMESTAMP => '2026-09-01 00:00:00'::TIMESTAMP)` recupera o
  estado anterior. Excelente para auditoria e para responder "o número mudou, quando?".
- **Custo**: `QUERY_HISTORY` e `WAREHOUSE_LOAD_HISTORY` mostram onde os créditos foram consumidos.
- **Falhas de query**: muito mais rígido que MySQL — identificador inexistente quebra a query. Isso é
  desejável quando o assunto é dado.
