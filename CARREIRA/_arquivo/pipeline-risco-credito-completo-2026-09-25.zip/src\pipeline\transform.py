"""Camada silver (staging): limpeza, padronizacao, nulos, deduplicacao e campos derivados.

Regras implementadas. Cada constante abaixo e a documentacao viva da regra, e o resultado da validacao
com esse nome vai para data/quality/resultado_validacoes.csv (linhagem para governanca).

  REGRA_SITUACAO        texto em minusculo, sem espaco duplicado, mapeado para vocabulario controlado
  REGRA_NULO            limite_atribuido nulo ou zero vira 0 e ganha flag
  REGRA_DEDUP           uma linha por cliente, mantendo a avaliacao mais recente
  DERIVADO_USO_LIMITE   uso_limite = limite_atribuido / faturamento_anual, protegido contra divisao por zero
  DERIVADO_CLIENTE_ATIVO 1 quando existe proposta aprovada
"""
from __future__ import annotations

from pyspark.sql import DataFrame, Window
from pyspark.sql.functions import (
    coalesce,
    col,
    count,
    lit,
    lower,
    regexp_replace,
    round as _round,
    row_number,
    trim,
    when,
)

REGRA_SITUACAO = "trim + lower + mapeamento para vocabulario controlado"
REGRA_NULO = "coalesce(limite_atribuido, 0) + flag_limite_nulo"
REGRA_DEDUP = "row_number por id_cliente ordenado por data_avaliacao desc"
DERIVADO_USO_LIMITE = "limite_atribuido / faturamento_anual, protegido contra divisao por zero"
DERIVADO_CLIENTE_ATIVO = "1 quando existe proposta com situacao aprovada"


def normalizar_clientes(df: DataFrame) -> DataFrame:
    return df.withColumn("segmento", lower(trim(col("segmento")))) \
            .withColumn("faturamento_anual", coalesce(col("faturamento_anual"), lit(0)))


def normalizar_propostas(df: DataFrame) -> DataFrame:
    limpa = regexp_replace(lower(trim(col("situacao"))), r"\s+", " ")
    mapa = (
        when(limpa.rlike("aprovad"), "aprovada")
        .when(limpa.rlike("recusad|negad"), "recusada")
        .when(limpa.rlike("analise"), "em_analise")
        .otherwise("desconhecida")
    )
    return df.withColumn("situacao", limpa).withColumn("situacao_padrao", mapa)


def normalizar_limites(df: DataFrame) -> DataFrame:
    w = Window.partitionBy("id_cliente").orderBy(col("data_avaliacao").desc())
    return (
        df.withColumn(
            "flag_limite_nulo",
            when(col("limite_atribuido").isNull() | (col("limite_atribuido") == 0), 1).otherwise(0),
        )
        .withColumn("limite_atribuido", coalesce(col("limite_atribuido"), lit(0)))
        .withColumn("_rank", row_number().over(w))
        .filter(col("_rank") == 1)
        .drop("_rank")
    )


def deduplicar(df: DataFrame, chave: str, ordem: str) -> DataFrame:
    w = Window.partitionBy(chave).orderBy(ordem)
    return df.withColumn("_rank", row_number().over(w)).filter(col("_rank") == 1).drop("_rank")


COLUNAS_AUDITORIA = ("dt_carga", "dt_carga_ts", "origem")


def _sem_auditoria(df: DataFrame) -> DataFrame:
    """Tira as colunas de controle de carga antes do join.

    Todas as tabelas da bronze recebem dt_carga, dt_carga_ts e origem. Sem remover das
    tabelas que sao apenas atributos do cliente, o join da camada gold fica com coluna
    duplicada e o particionamento por dt_carga quebra com referencia ambigua.
    """
    return df.drop(*[c for c in COLUNAS_AUDITORIA if c in df.columns])


def criar_campos_derivados(clientes: DataFrame, propostas: DataFrame, limites: DataFrame) -> DataFrame:
    """Campos derivados a partir de um ou mais campos de origem."""
    aprovadas = (
        _sem_auditoria(propostas)
        .filter(col("situacao_padrao") == "aprovada")
        .groupBy("id_cliente")
        .agg(count("id_proposta").alias("qtd_propostas_aprovadas"))
    )

    base = clientes.join(_sem_auditoria(limites), on="id_cliente", how="left").join(
        aprovadas, on="id_cliente", how="left"
    )

    return (
        base.withColumn("qtd_propostas_aprovadas", coalesce(col("qtd_propostas_aprovadas"), lit(0)))
        .withColumn("cliente_ativo", when(col("qtd_propostas_aprovadas") > 0, 1).otherwise(0))
        .withColumn(
            "uso_limite",
            when(
                col("faturamento_anual") > 0,
                _round(col("limite_atribuido") / col("faturamento_anual"), 4),
            ).otherwise(lit(0.0)),
        )
    )
