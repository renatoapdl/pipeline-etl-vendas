"""Sessao Spark centralizada (local ou cluster).

Variaveis de ambiente:
  SPARK_MASTER, INPUT_PATH, OUTPUT_PATH, SHUFFLE_PARTITIONS
"""
from __future__ import annotations

import os
from pathlib import Path

from pyspark.sql import SparkSession

INPUT_PATH = Path(os.getenv("INPUT_PATH", "data/raw")).resolve()
OUTPUT_PATH = Path(os.getenv("OUTPUT_PATH", "data")).resolve()


def _lancado_por_spark_submit() -> bool:
    """Diz se o processo foi iniciado pelo spark-submit.

    O launcher injeta PYSPARK_GATEWAY_PORT e PYSPARK_GATEWAY_SECRET no ambiente do driver
    Python. Sem checar isso, o .master() do codigo sobrescreve o --master da linha de
    comando: foi assim que --master local[2] do Job virou local[*] e o Job do Kubernetes
    parou de pedir executor para o cluster.
    """
    return "PYSPARK_GATEWAY_PORT" in os.environ


def get_spark(app_name: str = "pipeline-risco-credito") -> SparkSession:
    builder = (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.session.timeZone", "America/Fortaleza")
        .config("spark.sql.shuffle.partitions", os.getenv("SHUFFLE_PARTITIONS", "8"))
        .config("spark.sql.parquet.compression.codec", "snappy")
    )
    if not _lancado_por_spark_submit():
        builder = builder.master(os.getenv("SPARK_MASTER", "local[*]"))
    return builder.getOrCreate()
