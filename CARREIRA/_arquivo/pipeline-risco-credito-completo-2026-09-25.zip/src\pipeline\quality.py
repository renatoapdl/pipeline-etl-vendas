"""Quality gate: regras de validacao + profiling.

Duas saidas:
  data/quality/resultado_validacoes.csv  -- uma linha por regra executada (linhagem)
  data/quality/relatorio_profiling/      -- perfil por coluna, gravado pelo Spark

Severidade:
  critica  -- reprova a carga; a camada gold nao e publicada
  alerta   -- nao reprova, mas fica registrada para acompanhamento

O resultado gravado em CSV e lido de volta pela etapa de publicacao, que roda em outro
processo. Por isso a escrita usa o modulo csv: a observacao das regras contem virgula.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import reduce
from pathlib import Path

from pyspark.sql import DataFrame, functions as F
from pyspark.sql import types as T

CABECALHO = ["regra", "tabela", "coluna", "severidade", "aprovado", "observacao", "executado_em"]

TIPOS_NUMERICOS = (T.ByteType, T.ShortType, T.IntegerType, T.LongType, T.FloatType, T.DoubleType, T.DecimalType)
TIPOS_TEMPORAIS = (T.DateType, T.TimestampType)


@dataclass(frozen=True)
class Resultado:
    regra: str
    tabela: str
    coluna: str
    severidade: str
    aprovado: bool
    observacao: str

    def linha(self) -> list[str]:
        return [
            self.regra,
            self.tabela,
            self.coluna,
            self.severidade,
            "true" if self.aprovado else "false",
            self.observacao,
        ]


def nao_nulos(df: DataFrame, tabela: str, colunas: list[str]) -> list[Resultado]:
    """Regra critica: coluna obrigatoria nao pode ter nulo."""
    resultados = []
    for coluna in colunas:
        nulos = df.filter(F.col(coluna).isNull()).count()
        resultados.append(
            Resultado("nao_nulo", tabela, coluna, "critica", nulos == 0, f"{nulos} nulos")
        )
    return resultados


def valores_positivos(df: DataFrame, tabela: str, colunas: list[str]) -> list[Resultado]:
    """Regra critica: valor que precisa ser maior que zero (valor solicitado, prazo)."""
    resultados = []
    for coluna in colunas:
        invalidos = df.filter(F.col(coluna) <= 0).count()
        resultados.append(
            Resultado(
                "valor_positivo", tabela, coluna, "critica", invalidos == 0,
                f"{invalidos} valores menores ou iguais a zero",
            )
        )
    return resultados


def valores_dentro_do_dominio(
    df: DataFrame, tabela: str, coluna: str, permitidos: list[str]
) -> Resultado:
    """Regra critica: valor fora do vocabulario controlado invalida a linha."""
    invalidos = df.filter(~F.col(coluna).isin(permitidos)).count()
    return Resultado(
        regra="dominio_controlado",
        tabela=tabela,
        coluna=coluna,
        severidade="critica",
        aprovado=invalidos == 0,
        observacao=f"{invalidos} valores fora de {permitidos}",
    )


def unicidade(
    df: DataFrame, tabela: str, chave: str, severidade: str = "critica"
) -> Resultado:
    """Chave de negocio nao pode se repetir. Na bronze a duplicidade e esperada e
    tratada pela deduplicacao da silver, por isso roda com severidade alerta."""
    total, distintos = df.count(), df.select(chave).distinct().count()
    return Resultado(
        regra="unicidade",
        tabela=tabela,
        coluna=chave,
        severidade=severidade,
        aprovado=total == distintos,
        observacao=f"{total} linhas, {distintos} distintos, {total - distintos} duplicadas",
    )


def faixa_numerica(
    df: DataFrame, tabela: str, coluna: str, minimo: float, maximo: float
) -> Resultado:
    """Regra de alerta: valor fora da faixa esperada nao reprova, mas avisa."""
    fora = df.filter((F.col(coluna) < minimo) | (F.col(coluna) > maximo)).count()
    return Resultado(
        regra="faixa_numerica",
        tabela=tabela,
        coluna=coluna,
        severidade="alerta",
        aprovado=fora == 0,
        observacao=f"esperado [{minimo}, {maximo}], {fora} fora da faixa",
    )


def profiling(df: DataFrame, tabela: str) -> DataFrame:
    """Perfil por coluna: contagem, nulos, distintos, minimo, maximo, media e amplitude.

    Media so faz sentido para tipo numerico e amplitude so para data. Nas colunas onde a
    medida nao se aplica o valor vem nulo, para todas as linhas terem as mesmas colunas e
    poderem ser uniteadas.
    """
    linhas = []
    for campo in df.schema.fields:
        c = F.col(f"`{campo.name}`")
        numerico = isinstance(campo.dataType, TIPOS_NUMERICOS)
        temporal = isinstance(campo.dataType, TIPOS_TEMPORAIS)
        linhas.append(
            df.select(
                F.lit(tabela).alias("tabela"),
                F.lit(campo.name).alias("coluna"),
                F.lit(campo.dataType.simpleString()).alias("tipo"),
                F.count(F.lit(1)).alias("total"),
                F.count(c).alias("nao_nulos"),
                (F.count(F.lit(1)) - F.count(c)).alias("nulos"),
                F.countDistinct(c).alias("distintos"),
                F.min(c).cast("string").alias("minimo"),
                F.max(c).cast("string").alias("maximo"),
                F.avg(c).cast("string").alias("media") if numerico
                else F.lit(None).cast("string").alias("media"),
                F.datediff(F.max(c), F.min(c)).cast("string").alias("amplitude_dias") if temporal
                else F.lit(None).cast("string").alias("amplitude_dias"),
            )
        )
    return reduce(DataFrame.union, linhas)


def gravar_resultado(resultados: list[Resultado], caminho: Path) -> None:
    """Grava uma linha por regra executada, com o instante da execucao."""
    caminho.parent.mkdir(parents=True, exist_ok=True)
    executado_em = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with caminho.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(CABECALHO)
        for resultado in resultados:
            writer.writerow(resultado.linha() + [executado_em])


def ler_resultados(caminho: Path) -> list[Resultado]:
    """Le o resultado do gate de volta, para a publicacao decidir em outro processo."""
    if not caminho.exists():
        raise SystemExit(
            f"Resultado do quality gate ausente: {caminho}. Rode --camada quality antes."
        )

    resultados = []
    with caminho.open(encoding="utf-8") as f:
        for partes in csv.DictReader(f):
            if not (partes.get("regra") or "").strip():
                continue
            resultados.append(
                Resultado(
                    regra=partes["regra"],
                    tabela=partes["tabela"],
                    coluna=partes["coluna"],
                    severidade=partes["severidade"],
                    aprovado=partes["aprovado"] == "true",
                    observacao=partes["observacao"],
                )
            )
    return resultados


def houve_falha_critica(resultados: list[Resultado]) -> bool:
    return any(r.severidade == "critica" and not r.aprovado for r in resultados)
